# Y.M Apps — プロダクト一覧

## InkPress
E-Ink端末（BOOX等）向けの軽量PDFリーダー。Android。
1GB超のCBZ/PDFをページ単位ストリーミング、見開き・しおり対応。
ストア: https://play.google.com/store/apps/details?id=com.pino.inkpress

## PLAYCORD
NPB長期シミュレーション。Android。
ロスター・契約・FA・国際大会・ドラフト評価・二刀流・打順固定対応。
ストア: https://play.google.com/store/apps/details?id=com.pino.playcord

## RainWiper
ブラウザに雨を降らせるChrome拡張。
雫の屈折描画、ワイパー解剖学的円弧スイープ、雷音、Lite Mode（30fps）。
ストア: https://chromewebstore.google.com/detail/rainwiper/idmfgbdnebcjmndcmnfllhfidaakccmh

## Sidewalk Defender
HTML5ピクセルアートのレトロアーケード。歩道を守れ！
JUMP / PUNCH / KICK の3操作、COMBO×FEVER、ブラウザでこの場で起動。
itch.io: https://pinopino503.itch.io/sidewalk-defender

## ぴのくんスタンプ
LINEスタンプ。Y.M Apps のマスコット「ぴのくん」（白ねこ・黄色いキャップ）。
クリエイターページ: https://store.line.me/stickershop/author/1039160/ja

## SNS / Contact
X: https://x.com/Pinopino503
note: https://note.com/y_m656
itch.io: https://pinopino503.itch.io/
Email: y.m_games503@protonmail.com
